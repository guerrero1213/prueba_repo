/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilos;

/**
 *
 * @author beto
 */
public class proceso extends Thread {
    
public proceso(String nombreSemaforo, String[]colores, long tiempoInicial){
        super();
        this.nombreSemaforo=nombreSemaforo;
        this.cambioColor=colores;
        this.tiempoInicial=tiempoInicial;
    }
    private String nombreSemaforo;
    private String nombre;
    private String[] cambioColor;
    long tiempoInicial;
    
    @Override
    public void run(){
        System.out.println("comienza prceso para el "+this.nombreSemaforo);
        long control=(System.currentTimeMillis()-this.tiempoInicial)/1000;
        int controlColor=0;
        while(control!=100){
            control=(System.currentTimeMillis()-this.tiempoInicial)/1000;
            this.esperarXsegundos();
            System.out.println(this.nombreSemaforo+" esta en color "+cambioColor[controlColor]);
            controlColor++;
            if(controlColor==3){
                controlColor=0;
            }    
            
        }
        
    }
    private void esperarXsegundos() {
		try {
			Thread.sleep(10 * 1000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}
     public void setNombreSemaforo(String nombreSemaforo) {
        this.nombreSemaforo = nombreSemaforo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCambioColor(String[] cambioColor) {
        this.cambioColor = cambioColor;
    }

    public void setTiempoInicial(long tiempoInicial) {
        this.tiempoInicial = tiempoInicial;
    }

    public String getNombreSemaforo() {
        return nombreSemaforo;
    }

    public String getNombre() {
        return nombre;
    }

    public String[] getCambioColor() {
        return cambioColor;
    }

    public long getTiempoInicial() {
        return tiempoInicial;
    }
}
