/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilos;

/**
 *
 * @author beto
 */
public class Hilos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String cambioColor1[]={"verde","amarillo","rojo"};
        String cambioColor2[]={"rojo","amarillo","verde"};
        long cronometro = System.currentTimeMillis();
        proceso semaforo1=new proceso("semaforo 1",cambioColor1,cronometro);
        proceso semaforo2=new proceso("semaforo 2",cambioColor2,cronometro);
        semaforo1.start();
        semaforo2.start();
        
        
        
        
    }
    
}
